"use strict";
(() => {
var exports = {};
exports.id = 495;
exports.ids = [495];
exports.modules = {

/***/ 5217:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Register = (props)=>{
    const data = [
        {
            field: "firstname",
            type: "text",
            label: "First Name"
        },
        {
            field: "lastname",
            type: "text",
            label: "Last Name"
        },
        {
            field: "email",
            type: "email",
            label: "Email"
        },
        {
            field: "profession",
            type: "text",
            label: "Profession"
        },
        {
            field: "Country",
            type: "text",
            label: "Country"
        },
        {
            field: "Facebook",
            type: "text",
            label: "Facebook"
        },
        {
            field: "Instagram",
            type: "text",
            label: "Instagram"
        },
        {
            field: "Youtube",
            type: "text",
            label: "Youtube"
        },
        {
            field: "Website",
            type: "text",
            label: "Website"
        }, 
    ];
    // useEffect(() => {
    //   console.log(props.countries);
    // }, [])
    const { 0: userData , 1: setUserData  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        Country: "",
        Facebook: "",
        Instagram: "",
        Website: "",
        Youtube: "",
        email: "",
        firstname: "",
        lastname: "",
        profession: ""
    });
    const handleSubmit = (e)=>{
        e.preventDefault();
        console.log(userData);
    };
    const handleChange = (e)=>{
        setUserData({
            ...userData,
            [e.target.name]: e.target.value
        });
    };
    // const rnderDiv = (item: { field: string, type: string, label: string }, index: number): any => {  }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
        className: " py-12 min-h-[100vh] px-[10%] text-xl",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            onSubmit: handleSubmit,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "grid md:grid-cols-3 md:gap-6",
                    children: data.slice(0, 3).map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative z-0 mb-6 w-full group",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    required: true,
                                    onChange: handleChange,
                                    value: userData[item.field],
                                    type: item.type,
                                    name: item.field,
                                    id: item.field,
                                    className: "block py-2.5 px-0 w-full text-md bg-transparent border-0 border-b-2 border-gray-300 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-400 peer",
                                    placeholder: " "
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: item.field,
                                    className: "peer-focus:font-medium absolute text-sm text-gray-300 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-cyan-400 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                                    children: item.label
                                })
                            ]
                        }, index))
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "grid md:grid-cols-2 md:gap-6",
                    children: data.slice(3, 5).map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative z-0 mb-6 w-full group",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    required: true,
                                    onChange: handleChange,
                                    value: userData[item.field],
                                    type: item.type,
                                    name: item.field,
                                    id: item.field,
                                    className: "block py-2.5 px-0 w-full text-md bg-transparent border-0 border-b-2 border-gray-300 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-400 peer",
                                    placeholder: " "
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: item.field,
                                    className: "peer-focus:font-medium absolute text-sm text-gray-300 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-cyan-400 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                                    children: item.label
                                })
                            ]
                        }, index))
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "grid md:grid-cols-4 grid-cols-2 md:gap-6 gap-2",
                    children: data.slice(5).map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative z-0 mb-6 w-full group",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    required: true,
                                    onChange: handleChange,
                                    value: userData[item.field],
                                    type: item.type,
                                    name: item.field,
                                    id: item.field,
                                    className: "block py-2.5 px-0 w-full text-md bg-transparent border-0 border-b-2 border-gray-300 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-400 peer",
                                    placeholder: " "
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: item.field,
                                    className: "peer-focus:font-medium absolute text-sm text-gray-300 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-cyan-400 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                                    children: item.label
                                })
                            ]
                        }, index))
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-center mt-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        type: "submit",
                        className: "btn-blue px-12 rounded-md",
                        children: "Submit"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Register);
async function getStaticProps() {
    const countries = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get("https://restcountries.com/v3.1/all").then((response)=>{
        return response.data.map((c)=>{
            return {
                name: c.name,
                flag: c.flags
            };
        });
    });
    return {
        props: {
            countries
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5217));
module.exports = __webpack_exports__;

})();