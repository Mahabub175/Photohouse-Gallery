export const helperTesting = () => {
    return console.log('working!');
}