import React from "react";
import Home from "./index";
const Homee = () => <Home />;
export default Homee;
